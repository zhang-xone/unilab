"""Motion tracking environments for Unitree G1."""

from .box_tracking import G1BoxTrackingCfg, G1BoxTrackingEnv, G1BoxTrackingEnvCfg
from .flip_tracking import (
    G1ClimbTrackingCfg,
    G1ClimbTrackingEnv,
    G1ClimbTrackingEnvCfg,
    G1FlipTrackingCfg,
    G1FlipTrackingEnv,
    G1FlipTrackingEnvCfg,
    G1WallFlipTrackingCfg,
    G1WallFlipTrackingEnv,
    G1WallFlipTrackingEnvCfg,
)
from .flip_tracking_sac import (
    G1FlipTrackingSACCfg,
    G1FlipTrackingSACEnv,
    G1WallFlipTrackingSACCfg,
    G1WallFlipTrackingSACEnv,
)
from .motion_box_loader import BoxMotionData, BoxMotionLoader
from .tracking import (
    G1MotionTrackingCfg,
    G1MotionTrackingDeployEnv,
    G1MotionTrackingDeployEnvCfg,
    G1MotionTrackingEnv,
    G1MotionTrackingEnvCfg,
)
from .tracking_obs import G1WBTObsCfg, G1WBTObsEnv
from .tracking_sac import G1MotionTrackingSACCfg, G1MotionTrackingSACEnv

__all__ = [
    "G1MotionTrackingCfg",
    "G1MotionTrackingDeployEnv",
    "G1MotionTrackingDeployEnvCfg",
    "G1MotionTrackingEnv",
    "G1MotionTrackingEnvCfg",
    "G1MotionTrackingSACCfg",
    "G1MotionTrackingSACEnv",
    "G1WBTObsCfg",
    "G1WBTObsEnv",
    "G1FlipTrackingCfg",
    "G1FlipTrackingEnv",
    "G1FlipTrackingEnvCfg",
    "G1WallFlipTrackingCfg",
    "G1WallFlipTrackingEnv",
    "G1WallFlipTrackingEnvCfg",
    "G1FlipTrackingSACCfg",
    "G1FlipTrackingSACEnv",
    "G1WallFlipTrackingSACCfg",
    "G1WallFlipTrackingSACEnv",
    "G1ClimbTrackingCfg",
    "G1ClimbTrackingEnv",
    "G1ClimbTrackingEnvCfg",
    "G1BoxTrackingCfg",
    "G1BoxTrackingEnv",
    "G1BoxTrackingEnvCfg",
    "BoxMotionData",
    "BoxMotionLoader",
]
